/*
********************************************************************************
*  Description:	FM Module - Head of driver for EDA5800
*  Author:		Eric Xie
********************************************************************************
*/

#ifndef  _FMSI4702_H
#define  _FMSI4702_H

/**********************
* STATIC DATA         *
**********************/
extern u8 SI4702_FmWaitSTC(void)@"fm_rx_bank";
extern void SI4702_FmClrSTC(u8 muteonoff)@"fm_rx_bank";
extern void SI4702_RADIO_Power(u8 onoff)@"fm_rx_bank";
extern void SI4702_Tuner_FreqSet(unsigned int TunerFrequency)@"fm_rx_bank";
extern void SI4702_FmSeek(u8 seekDirection)@"fm_rx_bank";
extern void SI4702_RADIO_SetStereo(void)@"fm_rx_bank";
extern unsigned char SI4702_GetStereoStatus(void)@"fm_rx_bank";
extern void SI4702_RADIO_PlayStart(void)@"fm_rx_bank";
extern void SI4702_RADIO_Scan(void)@"fm_rx_bank";
#endif
