/*
********************************************************************************
*  Description:	FM Module - Driver for EDA5800
*  Author:		Eric Xie
********************************************************************************
*/
#ifdef SI4702
#include "i2c.h"
#include "si4702.h"
#include "deal_msg.h"
#include "lcd.h"

#define USE_SEEKMODE
#define     SI4702_TUNER_SEEKTH		0x0A//0X10
u8 fm_rssi;
/*
********************************************************************************
*  Function name :	FmWaitSTC()
*  Author:		Eric Xie
*  Description:	EDA5800 read STC.
********************************************************************************
*/
u8 SI4702_FmWaitSTC(void)@"fm_rx_bank" 
{
	#ifdef USE_SEEKMODE
	unsigned short temp;
	I2C_ReadFMxReg(4);
	if(gbradioseek)
		{
		temp=(unsigned int)((fm_read_reg[2]<<8)|fm_read_reg[3]);
		temp &=0x03ff;
		gwNowFreq = 8750 + temp*fm_step;
		RADIO_display();
		}
	#else
	I2C_ReadFMxReg(2);
	#endif
	
	if(fm_read_reg[0]&0x40)
		return(1);
	else
		return(0);
}
/*
********************************************************************************
*  Function name :	FmClrSTC()
*  Author:		Eric Xie
*  Description:	EDA5800 clear STC.
********************************************************************************
*/
void SI4702_FmClrSTC(u8 muteonoff)@"fm_rx_bank"
{            
	if(muteonoff)
		fm_write_reg[0]=0x00|gbtSetStereo;
	else
		fm_write_reg[0]=0x40|gbtSetStereo;
	//fm_write_reg[1]=0x01;
	fm_write_reg[2]=0x00;
	I2C_WriteFMxReg(3);
 }

void SI4702_Fmdelay(u8 aa)@"fm_rx_bank"
{
	while(aa--);
}

/*
********************************************************************************
*  Function name :	Tuner_PowerDown()
*  Author:		Eric Xie
*  Description:	EDA5800 disable chip.
********************************************************************************
*/

void SI4702_RADIO_Power(u8 onoff)@"fm_rx_bank"
{
	if(onoff){
			SCLDIROUT();
			I2C_CLK_HIGH();
			SDADIROUT();
			I2C_DATA_LOW();
			SI4702_Fmdelay(0xff);
			FMRST_LOW();
			//SI4702_Fmdelay(0xff);
			DelayMs(2);
			FMRST_HIGH();
			SI4702_Fmdelay(0xff);
			I2C_DATA_HIGH();
			DelayMs(1);

			fm_write_reg[0]=0x00;
			fm_write_reg[1]=0x00;
			fm_write_reg[2]=0x00;
			fm_write_reg[3]=0x00;
			fm_write_reg[4]=0x00;
			fm_write_reg[5]=0x80;
			fm_write_reg[6]=SI4702_TUNER_SEEKTH;
			if(fm_step==20)
				fm_write_reg[7]=0x0f;
			else if(fm_step==5)
				fm_write_reg[7]=0x2f;
			else
				fm_write_reg[7]=0x1f;
			fm_write_reg[8]=0x00;
			fm_write_reg[9]=0x38;
			fm_write_reg[10]=0x81;

		//	for(i=0;i<4;i++)
		//		fm_read_reg[i]=0;
	
		//	fm_write_reg[1]=0x00;
			I2C_WriteFMxReg(11);

	
    			DelayMs(200);		//  1s

			fm_write_reg[0]=gbtSetStereo;
			fm_write_reg[1]=0x01;
			I2C_WriteFMxReg(10);
    			DelayMs(40);			//200ms
    			gbtSetLocal=0;
					fm_rssi = SI4702_TUNER_SEEKTH;
		}	
	else
		{
		//I2C_WriteFMxReg(Si47XX_power_down,2);
		FMRST_LOW();
		}

}

/*
********************************************************************************
*  Function name :	Tuner_FreqSet()
*  Author:		Eric Xie
*  Description:	EDA5800 set frequency.
********************************************************************************
*/
void SI4702_Tuner_FreqSet(unsigned int TunerFrequency)@"fm_rx_bank"
{
	unsigned int   channel;

	fm_write_reg[0]=0x00|gbtSetStereo;
	//fm_write_reg[1]=0x01;
	fm_write_reg[2]=0x80;
	fm_write_reg[3]=0x00;

	channel=(unsigned int)((TunerFrequency-8750)/fm_step);

	fm_write_reg[2] |= (unsigned char)((channel>>8)&0x03);
	fm_write_reg[3] = (unsigned char)(channel&0xff);

	I2C_WriteFMxReg(4);
}    

void SI4702_FmSeek(u8 seekDirection)@"fm_rx_bank"
{
#ifdef USE_SEEKMODE
	if(gbradioseek==5)
		fm_write_reg[0]=0x07|gbtSetStereo;
	else
		{
		if(seekDirection) 
			fm_write_reg[0]=0x03|gbtSetStereo;
		else
			fm_write_reg[0]=0x01|gbtSetStereo;
		}
	I2C_WriteFMxReg(1);
#endif
}

void SI4702_RADIO_SetStereo(void)@"fm_rx_bank"
{   
	if(!gbtSetStereo)
		gbtSetStereo=0x20;
	else
		gbtSetStereo=0;
	
	fm_write_reg[0]=0x40|gbtSetStereo;
	I2C_WriteFMxReg(1);
}	
/*
********************************************************************************
*  Function name :	GetStereoStatus()
*  Author:		Eric Xie
*  Description:	Get stereo status.
********************************************************************************
*/
unsigned char SI4702_GetStereoStatus(void)@"fm_rx_bank"
{
	I2C_ReadFMxReg(4);// 2
	if((fm_read_reg[3]==0)&& !(fm_read_reg[2]&0x03))
		{
		if(gwNowFreq!=8750)
			{
			return 0xff;
			}
		}
	
	if (fm_read_reg[0] & 0x01)
		return 1;
	else
		return 0;
}

void SI4702_RADIO_SetLocal(void)@"fm_rx_bank"
{   
	gbtSetLocal=!gbtSetLocal;
	if(gbtSetLocal)
		fm_rssi = SI4702_TUNER_SEEKTH+15;
	else
		fm_rssi = SI4702_TUNER_SEEKTH;
	fm_write_reg[6]=fm_rssi;		
	I2C_WriteFMxReg(8);
  DelayMs(5);
}	

void SI4702_RADIO_PlayStart(void)@"fm_rx_bank"
{
	switch(radiosubstate)
		{
		case TUNER_PLAY_START:
			if (gbTunerTimer ) break;
			RADIO_PlayStart_init();
			break;
			
		case TUNER_MUTE_ON:
			if (gbTunerTimer ) break;
			gbTunerTimer = SYS_100ms;
			delaycounter++;
			if(SI4702_FmWaitSTC()||delaycounter>250)
        			{
				SI4702_FmClrSTC(fasttune);
				radiosubstate=TUNER_PLAY_END;
				delaycounter=0;
				}
			break;

		case TUNER_PLAY_END:
			if (gbTunerTimer ) break;
			gbTunerTimer = SYS_100ms;
			delaycounter++;
			if(!SI4702_FmWaitSTC()||delaycounter>250)
				{
				//if(!fasttune && music_vol_ext)
					AMP_UNMUTE();
				RadioMainState=TUNER_IDLE;
				radiosubstate=TUNER_SUB_IDLE;
				gbIdleTimer=0;
				}
			break;
			
		}
}

void SI4702_RADIO_Scan(void)@"fm_rx_bank"
{
	#ifdef USE_SEEKMODE
	unsigned short temp1;
	#endif	

	switch (radiosubstate) 
		{
		
		case TUNER_SCAN_START:
			if (gbTunerTimer ) break;
			RADIO_SeekStart();
			break;

		case TUNER_SCAN_STC:
			if (gbTunerTimer ) break;
			gbTunerTimer = SYS_50ms;
			delaycounter++;
			if(SI4702_FmWaitSTC()||delaycounter>250)
        			{	
				SI4702_FmClrSTC(1);
				radiosubstate=TUNER_SCAN_SEEK_END;
				gbTunerTimer =0;
				delaycounter=0;
				}
			break;

		case TUNER_SCAN_SEEK_END:
			if (gbTunerTimer ) break;
			delaycounter++;
			gbTunerTimer = SYS_50ms;
			if(!SI4702_FmWaitSTC()||delaycounter>250)
				{
				I2C_ReadFMxReg(4);
		#ifdef USE_SEEKMODE
				temp1=(unsigned int)((fm_read_reg[2]<<8)|fm_read_reg[3]);
				temp1 &=0x03ff;
				gwNowFreq = 8750 + temp1*fm_step;
		#endif		
				if(((fm_read_reg[0]&0x30)==0)&&(fm_read_reg[1]>=fm_rssi/*SI4702_TUNER_SEEKTH*/))
					{
					RADIO_ScanJudge(1);
		#ifdef USE_SEEKMODE
					RADIO_display();
		#endif
					}
				else
					{
					RADIO_ScanJudge(0);
					}
				}
			break;
			
		case TUNER_SCAN_SEEK:
			if (gbTunerTimer ) break;
			#ifdef USE_SEEKMODE
			RADIO_SeekNext(1);
			#else
			RADIO_SeekNext(0);
			#endif
			break;

		default:
			break;
    }
}

#undef USE_SEEKMODE
#endif
